package com.example.messageviewer;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView; // RecyclerView wyświetlający listy wiadomości
    private MessageAdapter adapter;   // Adapter zarządzający danymi w RecyclerView

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicjalizacja RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // lista pionowa
        fetchMessages(); // Pobranie wiadomości z API
    }

    private void fetchMessages() {
        ApiService apiService = RetrofitClient.getInstance();
        Call<List<Message>> call = apiService.getMessages();

        // Wywołanie pobrania danych z API
        call.enqueue(new Callback<List<Message>>() {
            @Override
            public void onResponse(Call<List<Message>> call, Response<List<Message>> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Message> messages = response.body(); // Pobranie listy wiadomości z odpowiedzi
                    adapter = new MessageAdapter(messages);
                    recyclerView.setAdapter(adapter);
                } else {
                    // Obsługa błędu przy złej odpowiedzi
                    Toast.makeText(MainActivity.this, "Błąd pobierania danych ", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Message>> call, Throwable t) {
                // Obsługa błędu nieudanego połączenia z API
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
