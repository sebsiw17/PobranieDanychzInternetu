package com.example.messageviewer;

import retrofit2.Call;
import retrofit2.http.GET;
import java.util.List;

public interface ApiService {
    @GET("5TP/")
    Call<List<Message>> getMessages();
}
