package com.example.messageviewer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Adapter zarządzający wyświetlaniem wiadomości w RecyclerView
public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    private List<Message> messages; // Lista wyświetlanych wiadomości

    // Konstruktor adaptera przyjmujący listę
    public MessageAdapter(List<Message> messages) {
        this.messages = messages;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false);
        return new MessageViewHolder(view);
    }

    // Związanie danych wiadomości z widokiem
    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        // Pobranie wiadomości z listy
        Message message = messages.get(position);

        // Ustawienie danych wiadomości
        holder.title.setText(message.getTitle()); // Tytuł
        holder.description.setText(message.getDescription()); // Opis
        holder.date.setText(message.getDate()); // Data
        holder.author.setText(message.getAuthor()); // Autor
        holder.content.setText(message.getContent()); // Treść
    }

    // Zwrot liczy wiadomości w liście
    @Override
    public int getItemCount() {
        return messages.size();
    }

    public static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView title, description, date, author, content; // Pola do wyświetlania danych wiadomości

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);

            // Inicjalizacja widoków
            title = itemView.findViewById(R.id.messageTitle); // Widok dla tytułu
            description = itemView.findViewById(R.id.messageDescription); // Widok dla opisu
            date = itemView.findViewById(R.id.messageDate); // Widok dla daty
            author = itemView.findViewById(R.id.messageAuthor); // Widok dla autora
            content = itemView.findViewById(R.id.messageContent); // widok dla treści
        }
    }
}
