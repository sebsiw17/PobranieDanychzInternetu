package com.example.messageviewer;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    private static final String BASE_URL = "http://json.itmargen.com/";

    private static Retrofit retrofit;

    public static ApiService getInstance() {
        // Sprawdzenie czy obiekt Retrofit już istnieje i zbudowanie go jeśli nie istnieje
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create()) // Konwerter JSON
                    .build();
        }

        return retrofit.create(ApiService.class);
    }
}
